package com.tk.app.controller;

import com.tk.app.service.TaskService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/{domainKey}/project/{projectId}") // 맨 앞에 '/' 추가 권장
public class ProjectController {

    private final TaskService taskService;

    @GetMapping("")
    public String projectDetail(
            @PathVariable("domainKey") String domainKey,
            @PathVariable("projectId") Long projectId,
            @RequestParam(name = "tab", defaultValue = "feed") String tab,
            Model model) {
        
        if (!tab.matches("feed|task|gantt|calendar|file")) {
            tab = "feed";
        }
        
        // 1. URL 경로 정보 Model에 추가 (템플릿 내 탭 이동 및 API 호출에 필수)
        model.addAttribute("domainKey", domainKey);
        model.addAttribute("projectId", projectId);
        model.addAttribute("activeTab", tab);
        model.addAttribute("projectName", "Taskwaka 시작가이드");

        // 2. 업무 탭인 경우 서버 사이드 렌더링(SSR)을 위해 DB 데이터 전달
        if ("task".equals(tab)) {
            model.addAttribute("tasks", taskService.getTaskList(projectId));
        }
        
        return "project/project_layout";
    }
}